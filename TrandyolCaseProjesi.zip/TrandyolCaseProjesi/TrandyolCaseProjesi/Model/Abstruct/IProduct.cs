﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrandyolCaseProjesi.Model.Abstruct
{
    interface IProduct
    {
        int ProductId { get; set; }

        int CategoryId { get; set; }

        string ProductName { get; set; }

        double ProductPrice { get; set; }
    }
}
