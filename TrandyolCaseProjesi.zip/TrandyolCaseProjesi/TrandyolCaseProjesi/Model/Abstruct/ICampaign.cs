﻿using TrandyolCaseProjesi.Model.Enum;

namespace TrandyolCaseProjesi.Model.Abstruct
{
    interface ICampaign
    {
        ICategory Category{ get; set; }
        double DiscountRate { get; set; }
        int Quality { get; set; }
        DiscountType DiscountType { get; set; }
    }
}
