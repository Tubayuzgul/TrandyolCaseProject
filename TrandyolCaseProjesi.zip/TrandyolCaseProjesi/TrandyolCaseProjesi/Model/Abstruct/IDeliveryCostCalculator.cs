﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrandyolCaseProjesi.Model.Abstruct
{
    interface IDeliveryCostCalculator
    {
        /// <summary>
        /// Teslim maliyeti
        /// </summary>
        double CostPerDelivery { get; set; }

        /// <summary>
        /// Ürün maliyeti
        /// </summary>
        double CostPerProduct { get; set; }

        /// <summary>
        /// Sabit maliyet=2,99
        /// </summary>
        double FixedCost { get; set; }

        double CalculateFor(ICart cart);

       
    }
}
