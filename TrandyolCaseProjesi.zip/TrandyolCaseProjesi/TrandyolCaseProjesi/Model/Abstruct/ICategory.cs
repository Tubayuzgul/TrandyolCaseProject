﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrandyolCaseProjesi.Model.Abstruct
{
    interface ICategory
    {
         int CategoryId { get; set; }
         string CategoryName { get; set; }
         int? ParentCategoryId { get; set; }
    }
}
