﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrandyolCaseProjesi.Model.Enum;

namespace TrandyolCaseProjesi.Model.Abstruct
{
    interface ICoupons
    {
         int CartTotalPrice { get; set; }
         double DiscountRate { get; set; }
         DiscountType DiscountType { get; set; }

    }
}
