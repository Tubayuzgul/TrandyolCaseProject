﻿using System.Collections.Generic;

namespace TrandyolCaseProjesi.Model.Abstruct
{
    interface ICart
    {
        List<IProduct> PrdocutList {get;  set; }

        double TotalAmount { get; set; }

        /// <summary>
        /// Sepetteki ürün adedi
        /// </summary>
        int Quantity { get; set; }

        void ApplyCoupon(ICoupons coupons);
        /// <summary>
        /// İndirimler yapıldıktan sonraki fiyat
        /// </summary>
        /// <returns></returns>
        double GetTotalAmountAfterDiscounts();

        /// <summary>
        /// Kupon ile yapılan toplam indirim
        /// </summary>
        /// <returns></returns>
        double GetCouponDiscount();

        /// <summary>
        /// Toplam kampanya indirimi
        /// </summary>
        /// <returns></returns>
        double GetCampaignDiscount();

        /// <summary>
        /// Teslimat ücreti
        /// </summary>
        /// <returns></returns>
        double GetDeliveryCost();

        /// <summary>
        /// Sonuçalr
        /// </summary>
        void   Print();

        void AddItem(IProduct product, int quality);

        void ApplyDiscounts(params ICampaign[] list);

        void SetDeliveryCost(double deliveryCost);
    }
}
