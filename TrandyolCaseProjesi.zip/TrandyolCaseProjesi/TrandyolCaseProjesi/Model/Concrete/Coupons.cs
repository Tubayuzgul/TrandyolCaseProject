﻿using TrandyolCaseProjesi.Model.Abstruct;
using TrandyolCaseProjesi.Model.Enum;

namespace TrandyolCaseProjesi.Model.Concrete
{
    class Coupons : ICoupons
    {
        public int CartTotalPrice { get; set; }
        public double DiscountRate { get; set; }
        public DiscountType DiscountType { get; set; }

       public  Coupons(int cartTotalPrice, double discountRate, DiscountType discountType)
        {
            CartTotalPrice = cartTotalPrice;
            DiscountRate = discountRate;
            DiscountType = DiscountType;
        }
    }
}
