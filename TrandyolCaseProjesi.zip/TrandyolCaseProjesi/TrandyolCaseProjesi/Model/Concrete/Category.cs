﻿using TrandyolCaseProjesi.Model.Abstruct;
using TrandyolCaseProjesi.Model.Concrete;

namespace TrandyolCaseProjesi.Model
{
    public class Category : ICategory
    {
        public Category(int categoryID,  string categoryName  , int? parentCategoryID)
        {
           CategoryId = categoryID;
           CategoryName = categoryName;
           ParentCategoryId = parentCategoryID;
           CategoryList.AddCategory(this);
        }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int? ParentCategoryId { get; set; }

    }
}
