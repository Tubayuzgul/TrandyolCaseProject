﻿using TrandyolCaseProjesi.Model.Abstruct;

namespace TrandyolCaseProjesi.Model
{
    public class Product : IProduct
    {
        public Product(int productId, int categoryId, string productName, double productPrice)
        {
            ProductId = productId;
            CategoryId = categoryId;
            ProductName = productName;
            ProductPrice = productPrice;
        }
        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public string ProductName { get; set; }
        public double ProductPrice { get; set; }
    }
}
