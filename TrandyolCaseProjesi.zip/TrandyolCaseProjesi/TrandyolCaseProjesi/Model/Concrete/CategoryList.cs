﻿using System.Collections.Generic;
using System.Linq;

namespace TrandyolCaseProjesi.Model.Concrete
{
    public static class CategoryList
    {
        static private List<Category> Categories { get; set;  }

        static public string GetCategoryNameById(int id)
        {
          string result = Categories.FirstOrDefault(x => x.CategoryId == id).CategoryName;

            return result;
        }
        static public void AddCategory(Category category)
        {
            if (Categories == null )
                 Categories = new List<Category>();
            
              Categories.Add(category);
           
        }

    }
}
