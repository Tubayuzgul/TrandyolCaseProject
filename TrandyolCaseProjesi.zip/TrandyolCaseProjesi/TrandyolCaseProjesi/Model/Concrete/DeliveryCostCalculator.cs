﻿using System.Linq;
using TrandyolCaseProjesi.Model.Abstruct;

namespace TrandyolCaseProjesi.Model.Concrete
{
    class DeliveryCostCalculator : IDeliveryCostCalculator
    {
        public double CostPerDelivery { get; set; }
        public double CostPerProduct { get; set; }
        public double FixedCost { get; set; }
        private double  DeliveryCost { get; set; }
        private int NumberOfDeliveries { get; set; } = 0;
        private int NumberOfProduct { get; set; }

        public  DeliveryCostCalculator(double costPerDelivery, double costPerProduct, double fixedCost)
        {
            CostPerDelivery = costPerDelivery;
            CostPerProduct = costPerProduct;
            FixedCost = fixedCost;
        }
        /// <summary>
        /// Teslimat maliyeti hesaplandı
        /// </summary>
        /// <param name="cart">Sepet</param>
        /// <returns>Teslimant maliyeti sonucu</returns>
        public double CalculateFor(ICart cart)
        {
            if (cart!=null)
            {
                NumberOfProduct = cart.PrdocutList.Count();
                NumberOfDeliveries = cart.PrdocutList.GroupBy(x => x.CategoryId).Count();

                DeliveryCost = (CostPerDelivery * NumberOfDeliveries) + (CostPerProduct + NumberOfProduct) + FixedCost;
                cart.SetDeliveryCost(DeliveryCost);
            }
            return DeliveryCost;
        }
    }
}
