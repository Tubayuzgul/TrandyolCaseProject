﻿using TrandyolCaseProjesi.Model.Abstruct;
using TrandyolCaseProjesi.Model.Enum;

namespace TrandyolCaseProjesi.Model.Concrete
{
    class Campaign : ICampaign
    {
        public ICategory Category { get; set; }
        public double DiscountRate { get; set; }
        public int Quality { get; set; }
        public DiscountType DiscountType { get; set; }

        public Campaign(ICategory category, double discountRate, int quality, DiscountType discountType)
        {
            Category = category;
            DiscountRate = discountRate;
            Quality = quality;
            DiscountType = discountType;
        }
    }
}
