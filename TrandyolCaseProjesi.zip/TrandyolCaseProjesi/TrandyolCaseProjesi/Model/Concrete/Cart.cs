﻿using System;
using System.Collections.Generic;
using System.Linq;
using TrandyolCaseProjesi.Model.Abstruct;
using TrandyolCaseProjesi.Model.Concrete;
using TrandyolCaseProjesi.Model.Enum;

namespace TrandyolCaseProjesi.Model
{
    class Cart : ICart
    {
        /// <summary>
        /// Ürün listesi
        /// </summary>
        public List<IProduct> PrdocutList { get; set; }
       
        /// <summary>
        /// Toplam son tutar
        /// </summary>
        public double TotalAmount { get; set; } = 0;

        /// <summary>
        /// Ürün Adedi
        /// </summary>
        public int Quantity { get; set; } = 0;
       
        /// <summary>
        /// İndirim Tutarı
        /// </summary>
        public double DiscountTotal { get; set; }

        /// <summary>
        /// En yüksek kampanya indirimi
        /// </summary>
        private double MaxDiscountTotal { get; set; } = 0;

        /// <summary>
        /// Uygulanan kampanya
        /// </summary>
        private ICampaign AppliedCampaign { get; set; }

        /// <summary>
        /// Uygulanan kupon
        /// </summary>
        private ICoupons AppliedCoupon { get; set; }

        /// <summary>
        /// Toplam campanya indirimi
        /// </summary>
        private double TotalCampaignDiscount { get; set; }

        /// <summary>
        /// Toplam kupon indirimi
        /// </summary>
        private double TotalCoupunDiscount { get; set; }

        /// <summary>
        /// Teslimat maliyeti 
        /// </summary>
        private double DeliveryCost { get; set; }

        /// <summary>
        /// Teslimat maliyetini DeliveryCostCalculator'den getirecek
        /// </summary>
        /// <param name="deliveryCost"></param>
        public void SetDeliveryCost(double deliveryCost)
        {   
            DeliveryCost = deliveryCost;
        }

        public void AddItem(IProduct product, int quality)
        {
            if (PrdocutList == null)
                PrdocutList = new List<IProduct>();

            for (int i = 0; i < quality; i++)
            {
                PrdocutList.Add(product);
                TotalAmount = TotalAmount + product.ProductPrice;
            }
            if (Quantity!=quality)
            {
                Quantity = Quantity + quality;
            }
           
        }

        public void ApplyDiscounts(params ICampaign[] list)
        {

            for (int i = 0; i < list.Length; i++)
            {
                int categoryTotal = PrdocutList.Where(x => x.CategoryId == list[i].Category.CategoryId).Count();

                double productTotal = PrdocutList.Where(x => x.CategoryId == list[i].Category.CategoryId).Sum(x => x.ProductPrice);

                if (categoryTotal >= list[i].Quality && list[i].DiscountType == DiscountType.Rate)
                    DiscountTotal = (productTotal) * (list[i].DiscountRate) / 100;

                if (categoryTotal >= list[i].Quality && list[i].DiscountType == DiscountType.Amount)
                    DiscountTotal = list[i].DiscountRate;

                if (DiscountTotal > MaxDiscountTotal)
                {
                    MaxDiscountTotal = DiscountTotal;
                    AppliedCampaign = list[i];
                }

            }
            TotalCampaignDiscount = MaxDiscountTotal;
        }

        public void ApplyCoupon(ICoupons coupon)
        {
            if (coupon == null)
                return;

            if (AppliedCampaign == null && TotalAmount >= coupon.CartTotalPrice && coupon.DiscountType == DiscountType.Rate)
                TotalCoupunDiscount = (TotalAmount * coupon.DiscountRate) / 100;
            else if (AppliedCampaign != null && TotalAmount >= coupon.CartTotalPrice && coupon.DiscountType == DiscountType.Rate)
                TotalCoupunDiscount = ((TotalAmount - TotalCampaignDiscount) * coupon.DiscountRate) / 100;

            AppliedCoupon = coupon;
        }

        public double GetCampaignDiscount()
        {
            return TotalCampaignDiscount;
        }
        public double GetCouponDiscount()
        {
            return TotalCoupunDiscount;
        }
        public double GetTotalAmountAfterDiscounts()
        {
            return (TotalAmount - (TotalCampaignDiscount + TotalCoupunDiscount));
        }

        public double GetDeliveryCost()
        {
            return DeliveryCost;
        }

        public void Print()
        {
         
            foreach (var item in PrdocutList)
            {

                Console.Write("Category Name : " + CategoryList.GetCategoryNameById(item.CategoryId).ToString());
                Console.Write("   Prdoduct Name :" + item.ProductName);
                Console.Write("   Unit Price  : " + item.ProductPrice);
                Console.WriteLine();
            }
            Console.WriteLine("   Quantity : " + Quantity);
            Console.WriteLine("   Total Price  : " + TotalAmount);
            Console.WriteLine("   Total Discount  : " + (TotalCampaignDiscount + TotalCoupunDiscount) + (" (Total Campaign Discount : " + TotalCampaignDiscount + " Total Coupun Discount : " + TotalCoupunDiscount + ")"));
            Console.WriteLine("   Last Amount  : " + GetTotalAmountAfterDiscounts());
            Console.WriteLine();
        }
    }
}
