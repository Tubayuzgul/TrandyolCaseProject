﻿namespace TrandyolCaseProjesi.Model.Constants
{

    public class Constants
    {
        public const double FixedCost = 2.99;
    }
}
