﻿using System;
using TrandyolCaseProjesi.Model;
using TrandyolCaseProjesi.Model.Concrete;
using TrandyolCaseProjesi.Model.Enum;
using TrandyolCaseProjesi.Model.Constants;
namespace TrandyolCaseProjesi
{
    class Program
    {
        static void Main(string[] args)
        {
            //Kategori oluşturuldu
            Category automobileCategory = new Category(1, "Automobil", null);
       
            //Ürün eklendi
            Product audi = new Product(1,1,"Audi",10);
          
            Cart cart = new Cart();
            cart.AddItem(audi,10);

            Campaign campaign1 = new Campaign(automobileCategory, 20, 3, DiscountType.Rate);
            Campaign campaign2 = new Campaign(automobileCategory, 50, 5, DiscountType.Rate);
            Campaign campaign3 = new Campaign(automobileCategory, 5, 5, DiscountType.Amount);
            cart.ApplyDiscounts(campaign1,campaign2,campaign3);

            Coupons coupons = new Coupons(100, 10, DiscountType.Rate);

            cart.ApplyCoupon(coupons);
            
            DeliveryCostCalculator deliveryCostCalculator = new DeliveryCostCalculator(6,3,Constants.FixedCost);
            deliveryCostCalculator.CalculateFor(cart);
            cart.Print();
            Console.ReadLine();
        }
    }
}
